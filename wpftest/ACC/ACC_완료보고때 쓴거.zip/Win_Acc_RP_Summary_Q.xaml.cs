﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WizMes_ChinHo_JA.PopUP;
using WPF.MDI;

namespace WizMes_ChinHo_JA
{
    /// <summary>
    /// Win_Acc_RP_Summary_Q.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Win_Acc_RP_Summary_Q : UserControl
    {
        private Microsoft.Office.Interop.Excel.Application excelapp;
        private Microsoft.Office.Interop.Excel.Workbook workbook;
        private Microsoft.Office.Interop.Excel.Worksheet worksheet;
        private Microsoft.Office.Interop.Excel.Range workrange;
        private Microsoft.Office.Interop.Excel.Worksheet copysheet;
        private Microsoft.Office.Interop.Excel.Worksheet pastesheet;
        // 엑셀 활용 용도 (프린트)

        WizMes_ChinHo_JA.PopUp.NoticeMessage msg = new PopUp.NoticeMessage();
        //(기다림 알림 메시지창)
        
        public Win_Acc_RP_Summary_Q()
        {
            InitializeComponent();
        }

        // 로드 이벤트.
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            Lib.Instance.UiLoading(sender);
            btnToday_Click(null, null);
            chkPeriod.IsChecked = true;
            SetComboBox();

            tbnOutware.IsChecked = true;  // 로드시 입금버튼 기본선택.
        }


        #region (상단 조회조건 체크박스 enable 모음)

        // 입금 / 출금 토글버튼
        private void tbnOutware_Checked(object sender, RoutedEventArgs e)
        {
            tbnStuffin.IsChecked = false;
            tbnOutware.IsChecked = true;

            // 입금버튼 클릭. > 명칭변경 및 항목, 그리드 체인지.
            tbnOutware_Checked();
        }
        // 입금 / 출금 토글버튼
        private void tbnOutware_Unchecked(object sender, RoutedEventArgs e)
        {
            tbnOutware.IsChecked = false;
            tbnStuffin.IsChecked = true;
        }
        // 입금 / 출금 토글버튼
        private void tbnStuffin_Checked(object sender, RoutedEventArgs e)
        {
            tbnOutware.IsChecked = false;
            tbnStuffin.IsChecked = true;

            // 출금버튼 클릭. > 명칭변경 및 항목, 그리드 체인지.
            tbnStuffin_Checked();
        }
        // 입금 / 출금 토글버튼
        private void tbnStuffin_Unchecked(object sender, RoutedEventArgs e)
        {
            tbnStuffin.IsChecked = false;
            tbnOutware.IsChecked = true;
        }





        // 기간
        private void lblPeriod_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (chkPeriod.IsChecked == true) { chkPeriod.IsChecked = false; }
            else { chkPeriod.IsChecked = true; }
        }
        // 기간
        private void chkPeriod_Checked(object sender, RoutedEventArgs e)
        {
            dtpSDate.IsEnabled = true;
            dtpEDate.IsEnabled = true;
        }
        // 기간
        private void chkPeriod_Unchecked(object sender, RoutedEventArgs e)
        {
            dtpSDate.IsEnabled = false;
            dtpEDate.IsEnabled = false;
        }


        #region (상단 조회 일자변경 버튼 이벤트)
        //금일
        private void btnToday_Click(object sender, RoutedEventArgs e)
        {
            dtpSDate.SelectedDate = DateTime.Today;
            dtpEDate.SelectedDate = DateTime.Today;
        }
        //금월
        private void btnThisMonth_Click(object sender, RoutedEventArgs e)
        {
            dtpSDate.SelectedDate = Lib.Instance.BringThisMonthDatetimeList()[0];
            dtpEDate.SelectedDate = Lib.Instance.BringThisMonthDatetimeList()[1];
        }
        //전월
        private void btnLastMonth_Click(object sender, RoutedEventArgs e)
        {
            dtpSDate.SelectedDate = Lib.Instance.BringLastMonthDatetimeList()[0];
            dtpEDate.SelectedDate = Lib.Instance.BringLastMonthDatetimeList()[1];
        }
        //전일
        private void btnYesterday_Click(object sender, RoutedEventArgs e)
        {
            dtpSDate.SelectedDate = DateTime.Today.AddDays(-1);
            dtpEDate.SelectedDate = DateTime.Today.AddDays(-1);
        }

        #endregion

      
        // 거래처
        private void lblCustom_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (chkCustom.IsChecked == true) { chkCustom.IsChecked = false; }
            else { chkCustom.IsChecked = true; }
        }
        // 거래처
        private void chkCustom_Checked(object sender, RoutedEventArgs e)
        {
            txtCustom.IsEnabled = true;
            btnPfCustom.IsEnabled = true;
            txtCustom.Focus();
        }
        // 거래처
        private void chkCustom_Unchecked(object sender, RoutedEventArgs e)
        {
            txtCustom.IsEnabled = false;
            btnPfCustom.IsEnabled = false;
        }
        // 거래처
        private void txtCustom_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                MainWindow.pf.ReturnCode(txtCustom, (int)Defind_CodeFind.DCF_CUSTOM, "");
            }
        }


        // 계좌정보
        private void lblAccountInfo_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (chkAccountInfo.IsChecked == true) { chkAccountInfo.IsChecked = false; }
            else { chkAccountInfo.IsChecked = true; }
        }
        // 계좌정보
        private void chkAccountInfo_Checked(object sender, RoutedEventArgs e)
        {
            txtAccountInfo.IsEnabled = true;
            btnpfAccountInfo.IsEnabled = true;
            txtAccountInfo.Focus();
        }
        // 계좌정보
        private void chkAccountInfo_Unchecked(object sender, RoutedEventArgs e)
        {
            txtAccountInfo.IsEnabled = false;
            btnpfAccountInfo.IsEnabled = false;
        }



        // 오더번호
        private void lblOrderNum_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (chkOrderNum.IsChecked == true) { chkOrderNum.IsChecked = false; }
            else { chkOrderNum.IsChecked = true; }
        }
        // 오더번호
        private void chkOrderNum_Checked(object sender, RoutedEventArgs e)
        {
            txtOrderNum.IsEnabled = true;
            btnPfOrderNum.IsEnabled = true;
            txtOrderNum.Focus();
        }
        // 오더번호
        private void chkOrderNum_Unchecked(object sender, RoutedEventArgs e)
        {
            txtOrderNum.IsEnabled = false;
            btnPfOrderNum.IsEnabled = false;
        }



        // 화폐
        private void lblMoney_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (chkMoney.IsChecked == true) { chkMoney.IsChecked = false; }
            else { chkMoney.IsChecked = true; }
        }
        // 화폐
        private void chkMoney_Checked(object sender, RoutedEventArgs e)
        {
            cboMoney.IsEnabled = true;
        }
        // 화폐
        private void chkMoney_Unchecked(object sender, RoutedEventArgs e)
        {
            cboMoney.IsEnabled = false;
        }

        #endregion


        #region (플러스파인더 모음)

        // 플러스파인더 >> 거래처.
        private void btnPfCustom_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.pf.ReturnCode(txtCustom, (int)Defind_CodeFind.DCF_CUSTOM, "");
        }


        // 플러스파인더 >> 계좌정보
        private void txtAccountInfo_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                MainWindow.pf.ReturnCode(txtAccountInfo, (int)Defind_CodeFind.DCF_AccountInfo, "");
            }
        }
        // 플러스파인더 >> 계좌정보
        private void btnpfAccountInfo_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.pf.ReturnCode(txtAccountInfo, (int)Defind_CodeFind.DCF_AccountInfo, "");
        }
             


        // 플러스파인더 >> 오더번호
        private void btnPfOrderNum_Click(object sender, RoutedEventArgs e)
        {
            // 4번.
            MainWindow.pf.ReturnCode(txtOrderNum, (int)Defind_CodeFind.DCF_ORDER, "");
        }
        // 플러스파인더 >> 오더번호
        private void txtOrderNum_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                // 4번.
                MainWindow.pf.ReturnCode(txtOrderNum, (int)Defind_CodeFind.DCF_ORDER, "");
            }
        }

        #endregion

    
        #region (콤보박스 세팅) SetComboBox
        private void SetComboBox()
        {

            //매입,매출 화폐단위(입력)
            List<string[]> listPrice = new List<string[]>();
            string[] Price01 = new string[] { "0", "₩" };
            string[] Price02 = new string[] { "1", "$" };
            listPrice.Add(Price01);
            listPrice.Add(Price02);

            ObservableCollection<CodeView> ovcPrice = ComboBoxUtil.Instance.Direct_SetComboBox(listPrice);
            this.cboMoney.ItemsSource = ovcPrice;
            this.cboMoney.DisplayMemberPath = "code_name";
            this.cboMoney.SelectedValuePath = "code_id";

        }

        #endregion

        #region (토글버튼 체크 체인지 이벤트) CheckedChange
        // 입금 클릭.
        private void tbnOutware_Checked()
        {
            this.DataContext = null;

            grbdgdInGrid.Visibility = Visibility.Hidden;
            grbdgdOutGrid.Visibility = Visibility.Visible;

        }

        // 출금 클릭.
        private void tbnStuffin_Checked()
        {
            this.DataContext = null;            

            grbdgdOutGrid.Visibility = Visibility.Hidden;
            grbdgdInGrid.Visibility = Visibility.Visible;

        }

        #endregion

        // 검색버튼 클릭.
        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            if (tbnOutware.IsChecked == true) // 입금용 그리드
            {
                FillGrid_dgdSummaryGrid();
            }
            else if (tbnStuffin.IsChecked == true) // 출금용 그리드
            {
                FillGrid_dgdOutSummaryGrid();
            }
        }

        #region (검색 >> 입출금 집계) FillGrid_dgdSummaryGrid
        // 입금용 그리드 채우기.
        private void FillGrid_dgdSummaryGrid()
        {
            if (dgdSummaryGrid.Items.Count > 0)
            {
                dgdSummaryGrid.Items.Clear();
            }

            try
            {
                //입금 / 출금 토글박스 구분.
                string bsGbnID = "2";
                
                if (tbnOutware.IsChecked == true) { bsGbnID = "2"; }
                else if (tbnStuffin. IsChecked == true) { bsGbnID = "1"; }

                // 일자 체크여부 yn
                int sBSDate = 0;
                if (chkPeriod.IsChecked == true) { sBSDate = 1; }

                DataSet ds = null;
                Dictionary<string, object> sqlParameter = new Dictionary<string, object>();
                sqlParameter.Clear();
                

                sqlParameter.Add("bsGbnID", bsGbnID);       // 입금 출금 구분자.
                sqlParameter.Add("sBSDate", sBSDate);
                sqlParameter.Add("sDate", chkPeriod.IsChecked == true ? dtpSDate.SelectedDate.Value.ToString("yyyyMMdd") : "");
                sqlParameter.Add("eDate", chkPeriod.IsChecked == true ? dtpEDate.SelectedDate.Value.ToString("yyyyMMdd") : "");

                sqlParameter.Add("CustomID", "");
                sqlParameter.Add("AccountID", "");
                sqlParameter.Add("OrderNo", "");
                sqlParameter.Add("CurrencyUnit", "");

                ds = DataStore.Instance.ProcedureToDataSet("xp_Acc_RP_Sum_Q", sqlParameter, false);


                if (ds != null && ds.Tables.Count > 0)
                {
                    DataTable dt = ds.Tables[0];
                    int i = 0;

                    if (dt.Rows.Count == 0)
                    {
                        MessageBox.Show("조회된 데이터가 없습니다.");
                    }
                    else
                    {
                        DataRowCollection drc = dt.Rows;
                        foreach (DataRow dr in drc)
                        {
                            if (dr["cls"].ToString() == "1")
                            {
                                var WinAccRPSummary = new Win_Acc_RP_Summary_Q_CodeView()
                                {
                                    Num = i + 1,

                                    cls = dr["cls"].ToString(),
                                    YYYY = dr["YYYY"].ToString(),
                                    MM = dr["MM"].ToString(),
                                    KCustom = dr["KCustom"].ToString(),
                                    BSItem = dr["BSItem"].ToString(),
                                    ForReceiveBillAmount = dr["ForReceiveBillAmount"].ToString(),
                                    CurrencyName = dr["CurrencyName"].ToString(),
                                    RATE = dr["RATE"].ToString(),

                                    ColorLightLightGray = "false",
                                    ColorLightGray = "false",
                                    ColorGray = "false"
                                };
                                // 콤마입히기 > 수량
                                if (Lib.Instance.IsNumOrAnother(WinAccRPSummary.ForReceiveBillAmount))
                                {
                                    WinAccRPSummary.ForReceiveBillAmount = Lib.Instance.returnNumStringZero(WinAccRPSummary.ForReceiveBillAmount);
                                }

                                dgdSummaryGrid.Items.Add(WinAccRPSummary);
                            }         
                            else if (dr["cls"].ToString() == "2")
                            {
                                var WinAccRPSummary = new Win_Acc_RP_Summary_Q_CodeView()
                                {
                                    Num = i + 1,

                                    cls = dr["cls"].ToString(),
                                    YYYY = dr["YYYY"].ToString(),
                                    MM = dr["MM"].ToString(),
                                    KCustom = dr["KCustom"].ToString(),
                                    BSItem = "거래처 계", //zzzz dr["Article"].ToString()
                                    ForReceiveBillAmount = dr["ForReceiveBillAmount"].ToString(),
                                    CurrencyName = dr["CurrencyName"].ToString(),
                                    RATE = dr["RATE"].ToString(),

                                    ColorLightLightGray = "true",
                                    ColorLightGray = "false",
                                    ColorGray = "false"
                                };
                                // 콤마입히기 > 수량
                                if (Lib.Instance.IsNumOrAnother(WinAccRPSummary.ForReceiveBillAmount))
                                {
                                    WinAccRPSummary.ForReceiveBillAmount = Lib.Instance.returnNumStringZero(WinAccRPSummary.ForReceiveBillAmount);
                                }

                                dgdSummaryGrid.Items.Add(WinAccRPSummary);
                            }
                            else if (dr["cls"].ToString() == "3")
                            {
                                var WinAccRPSummary = new Win_Acc_RP_Summary_Q_CodeView()
                                {
                                    Num = i + 1,

                                    cls = dr["cls"].ToString(),
                                    YYYY = dr["YYYY"].ToString(),
                                    MM = dr["MM"].ToString(), 
                                    KCustom = "월 합계", //zzzz dr["KCustom"].ToString()
                                    BSItem = dr["BSItem"].ToString(),
                                    ForReceiveBillAmount = dr["ForReceiveBillAmount"].ToString(),
                                    CurrencyName = dr["CurrencyName"].ToString(),
                                    RATE = dr["RATE"].ToString(),

                                    ColorLightLightGray = "true",
                                    ColorLightGray = "false",
                                    ColorGray = "false"
                                };
                                // 콤마입히기 > 수량
                                if (Lib.Instance.IsNumOrAnother(WinAccRPSummary.ForReceiveBillAmount))
                                {
                                    WinAccRPSummary.ForReceiveBillAmount = Lib.Instance.returnNumStringZero(WinAccRPSummary.ForReceiveBillAmount);
                                }

                                dgdSummaryGrid.Items.Add(WinAccRPSummary);
                            }
                            else if (dr["cls"].ToString() == "4")
                            {
                                var WinAccRPSummary = new Win_Acc_RP_Summary_Q_CodeView()
                                {
                                    Num = i + 1,

                                    cls = dr["cls"].ToString(),
                                    YYYY = dr["YYYY"].ToString(), 
                                    MM = "년 합계", //zzzz dr["MM"].ToString()
                                    KCustom = dr["KCustom"].ToString(),
                                    BSItem = dr["BSItem"].ToString(),
                                    ForReceiveBillAmount = dr["ForReceiveBillAmount"].ToString(),
                                    CurrencyName = dr["CurrencyName"].ToString(),
                                    RATE = dr["RATE"].ToString(),

                                    ColorLightLightGray = "false",
                                    ColorLightGray = "true",
                                    ColorGray = "false"
                                };
                                // 콤마입히기 > 수량
                                if (Lib.Instance.IsNumOrAnother(WinAccRPSummary.ForReceiveBillAmount))
                                {
                                    WinAccRPSummary.ForReceiveBillAmount = Lib.Instance.returnNumStringZero(WinAccRPSummary.ForReceiveBillAmount);
                                }

                                dgdSummaryGrid.Items.Add(WinAccRPSummary);
                            }
                            else if (dr["cls"].ToString() == "5")
                            {
                                var WinAccRPSummary = new Win_Acc_RP_Summary_Q_CodeView()
                                {
                                    Num = i + 1,

                                    cls = dr["cls"].ToString(),
                                    YYYY = "총 합계", //zzzz dr["YYYY"].ToString()
                                    MM = dr["MM"].ToString(),
                                    KCustom = dr["KCustom"].ToString(),
                                    BSItem = dr["BSItem"].ToString(),
                                    ForReceiveBillAmount = dr["ForReceiveBillAmount"].ToString(),
                                    CurrencyName = dr["CurrencyName"].ToString(),
                                    RATE = dr["RATE"].ToString(),

                                    ColorLightLightGray = "false",
                                    ColorLightGray = "false",
                                    ColorGray = "true"
                                };
                                // 콤마입히기 > 수량
                                if (Lib.Instance.IsNumOrAnother(WinAccRPSummary.ForReceiveBillAmount))
                                {
                                    WinAccRPSummary.ForReceiveBillAmount = Lib.Instance.returnNumStringZero(WinAccRPSummary.ForReceiveBillAmount);
                                }

                                dgdSummaryGrid.Items.Add(WinAccRPSummary);
                            }
                            i++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("오류 발생, 오류 내용 : " + ex.ToString());
            }
        }

        #endregion

        #region (검색 >> 입출금 집계) FillGrid_dgdOutSummaryGrid
        // 출금용 그리드 채우기.
        private void FillGrid_dgdOutSummaryGrid()
        {
            if (dgdOutSummaryGrid.Items.Count > 0)
            {
                dgdOutSummaryGrid.Items.Clear();
            }

            try
            {
                //입금 / 출금 토글박스 구분.
                string bsGbnID = "1";

                // 일자 체크여부 yn
                int sBSDate = 0;
                if (chkPeriod.IsChecked == true) { sBSDate = 1; }



                DataSet ds = null;
                Dictionary<string, object> sqlParameter = new Dictionary<string, object>();
                sqlParameter.Clear();
                sqlParameter.Add("bsGbnID", bsGbnID);       // 입금 출금 구분자.
                sqlParameter.Add("sBSDate", sBSDate);
                sqlParameter.Add("sDate", chkPeriod.IsChecked == true ? dtpSDate.SelectedDate.Value.ToString("yyyyMMdd") : "");
                sqlParameter.Add("eDate", chkPeriod.IsChecked == true ? dtpEDate.SelectedDate.Value.ToString("yyyyMMdd") : "");

                sqlParameter.Add("CustomID", "");
                sqlParameter.Add("AccountID", "");
                sqlParameter.Add("OrderNo", "");
                sqlParameter.Add("CurrencyUnit", "");

                ds = DataStore.Instance.ProcedureToDataSet("xp_Acc_RP_Sum_Q", sqlParameter, false);


                if (ds != null && ds.Tables.Count > 0)
                {
                    DataTable dt = ds.Tables[0];
                    int i = 0;

                    if (dt.Rows.Count == 0)
                    {
                        MessageBox.Show("조회된 데이터가 없습니다.");
                    }
                    else
                    {
                        DataRowCollection drc = dt.Rows;
                        foreach (DataRow dr in drc)
                        {
                            if (dr["cls"].ToString() == "1")
                            {
                                var WinAccRPSummary = new Win_Acc_RP_Summary_Q_CodeView()
                                {
                                    Num = i + 1,

                                    cls = dr["cls"].ToString(),
                                    YYYY = dr["YYYY"].ToString(),
                                    MM = dr["MM"].ToString(),
                                    KCustom = dr["KCustom"].ToString(),
                                    BSItem = dr["BSItem"].ToString(),
                                    ForReceiveBillAmount = dr["ForReceiveBillAmount"].ToString(),
                                    CurrencyName = dr["CurrencyName"].ToString(),
                                    RATE = dr["RATE"].ToString(),

                                    ColorLightLightGray = "false",
                                    ColorLightGray = "false",
                                    ColorGray = "false"
                                };
                                // 콤마입히기 > 수량
                                if (Lib.Instance.IsNumOrAnother(WinAccRPSummary.ForReceiveBillAmount))
                                {
                                    WinAccRPSummary.ForReceiveBillAmount = Lib.Instance.returnNumStringZero(WinAccRPSummary.ForReceiveBillAmount);
                                }

                                dgdOutSummaryGrid.Items.Add(WinAccRPSummary);
                            }                          
                            else if (dr["cls"].ToString() == "2")
                            {
                                var WinAccRPSummary = new Win_Acc_RP_Summary_Q_CodeView()
                                {
                                    Num = i + 1,

                                    cls = dr["cls"].ToString(),
                                    YYYY = dr["YYYY"].ToString(),
                                    MM = dr["MM"].ToString(),
                                    KCustom = dr["KCustom"].ToString(),
                                    BSItem = "거래처 계", //zzzz dr["Article"].ToString()
                                    ForReceiveBillAmount = dr["ForReceiveBillAmount"].ToString(),
                                    CurrencyName = dr["CurrencyName"].ToString(),
                                    RATE = dr["RATE"].ToString(),

                                    ColorLightLightGray = "true",
                                    ColorLightGray = "false",
                                    ColorGray = "false"
                                };
                                // 콤마입히기 > 수량
                                if (Lib.Instance.IsNumOrAnother(WinAccRPSummary.ForReceiveBillAmount))
                                {
                                    WinAccRPSummary.ForReceiveBillAmount = Lib.Instance.returnNumStringZero(WinAccRPSummary.ForReceiveBillAmount);
                                }

                                dgdOutSummaryGrid.Items.Add(WinAccRPSummary);
                            }
                            else if (dr["cls"].ToString() == "3")
                            {
                                var WinAccRPSummary = new Win_Acc_RP_Summary_Q_CodeView()
                                {
                                    Num = i + 1,

                                    cls = dr["cls"].ToString(),
                                    YYYY = dr["YYYY"].ToString(),
                                    MM = dr["MM"].ToString(),
                                    KCustom = "월 합계", //zzzz dr["KCustom"].ToString()
                                    BSItem = dr["BSItem"].ToString(),
                                    ForReceiveBillAmount = dr["ForReceiveBillAmount"].ToString(),
                                    CurrencyName = dr["CurrencyName"].ToString(),
                                    RATE = dr["RATE"].ToString(),

                                    ColorLightLightGray = "true",
                                    ColorLightGray = "false",
                                    ColorGray = "false"
                                };
                                // 콤마입히기 > 수량
                                if (Lib.Instance.IsNumOrAnother(WinAccRPSummary.ForReceiveBillAmount))
                                {
                                    WinAccRPSummary.ForReceiveBillAmount = Lib.Instance.returnNumStringZero(WinAccRPSummary.ForReceiveBillAmount);
                                }

                                dgdOutSummaryGrid.Items.Add(WinAccRPSummary);
                            }
                            else if (dr["cls"].ToString() == "4")
                            {
                                var WinAccRPSummary = new Win_Acc_RP_Summary_Q_CodeView()
                                {
                                    Num = i + 1,

                                    cls = dr["cls"].ToString(),
                                    YYYY = dr["YYYY"].ToString(),
                                    MM = "년 합계", //zzzz dr["MM"].ToString()
                                    KCustom = dr["KCustom"].ToString(),
                                    BSItem = dr["BSItem"].ToString(),
                                    ForReceiveBillAmount = dr["ForReceiveBillAmount"].ToString(),
                                    CurrencyName = dr["CurrencyName"].ToString(),
                                    RATE = dr["RATE"].ToString(),

                                    ColorLightLightGray = "false",
                                    ColorLightGray = "true",
                                    ColorGray = "false"
                                };
                                // 콤마입히기 > 수량
                                if (Lib.Instance.IsNumOrAnother(WinAccRPSummary.ForReceiveBillAmount))
                                {
                                    WinAccRPSummary.ForReceiveBillAmount = Lib.Instance.returnNumStringZero(WinAccRPSummary.ForReceiveBillAmount);
                                }

                                dgdOutSummaryGrid.Items.Add(WinAccRPSummary);
                            }
                            else if (dr["cls"].ToString() == "5")
                            {
                                var WinAccRPSummary = new Win_Acc_RP_Summary_Q_CodeView()
                                {
                                    Num = i + 1,

                                    cls = dr["cls"].ToString(),
                                    YYYY = "총 합계", //zzzz dr["YYYY"].ToString()
                                    MM = dr["MM"].ToString(),
                                    KCustom = dr["KCustom"].ToString(),
                                    BSItem = dr["BSItem"].ToString(),
                                    ForReceiveBillAmount = dr["ForReceiveBillAmount"].ToString(),
                                    CurrencyName = dr["CurrencyName"].ToString(),
                                    RATE = dr["RATE"].ToString(),

                                    ColorLightLightGray = "false",
                                    ColorLightGray = "false",
                                    ColorGray = "true"
                                };
                                // 콤마입히기 > 수량
                                if (Lib.Instance.IsNumOrAnother(WinAccRPSummary.ForReceiveBillAmount))
                                {
                                    WinAccRPSummary.ForReceiveBillAmount = Lib.Instance.returnNumStringZero(WinAccRPSummary.ForReceiveBillAmount);
                                }

                                dgdOutSummaryGrid.Items.Add(WinAccRPSummary);
                            }
                            i++;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("오류 발생, 오류 내용 : " + ex.ToString());
            }
        }

        #endregion


        //입금 / 출금 토글버튼
        private void chkCollectionYear_Checked(object sender, RoutedEventArgs e)
        {
            CollectionListAddMinusWithDatagrid();
        }

        private void chkCollectionYear_Unchecked(object sender, RoutedEventArgs e)
        {
            CollectionListAddMinusWithDatagrid();
        }

        private void chkCollectionMonth_Checked(object sender, RoutedEventArgs e)
        {
            CollectionListAddMinusWithDatagrid();
        }
        private void chkCollectionMonth_Unchecked(object sender, RoutedEventArgs e)
        {
            CollectionListAddMinusWithDatagrid();
        }

        private void chkCollectionCustom_Checked(object sender, RoutedEventArgs e)
        {
            CollectionListAddMinusWithDatagrid();
        }
        private void chkCollectionCustom_Unchecked(object sender, RoutedEventArgs e)
        {
            CollectionListAddMinusWithDatagrid();
        }

        private void chkCollectionAccountTitle_Checked(object sender, RoutedEventArgs e)
        {
            CollectionListAddMinusWithDatagrid();
        }
        private void chkCollectionAccountTitle_Unchecked(object sender, RoutedEventArgs e)
        {
            CollectionListAddMinusWithDatagrid();
        }


        #region (집계항목 체크 및 그리드 visible 작업) CollectionListAddMinusWithDatagrid
        private void CollectionListAddMinusWithDatagrid()
        {
            int i = 1;
            dgdtxtcolYear.Visibility = Visibility.Hidden;
            dgdtxtcolMonth.Visibility = Visibility.Hidden;
            dgdtxtcolCustom.Visibility = Visibility.Hidden;
            dgdtxtcolAccountTitle.Visibility = Visibility.Hidden;

            dgdtxtcolYear02.Visibility = Visibility.Hidden;
            dgdtxtcolMonth02.Visibility = Visibility.Hidden;
            dgdtxtcolCustom02.Visibility = Visibility.Hidden;
            dgdtxtcolAccountTitle02.Visibility = Visibility.Hidden;

            tbkCollection1.Text = string.Empty;
            tbkCollection2.Text = string.Empty;
            tbkCollection3.Text = string.Empty;
            tbkCollection4.Text = string.Empty;

            if (chkCollectionYear.IsChecked == true)
            {
                tbkCollection1.Text = i.ToString();
                tbkCollection1.Margin = new Thickness(3, 3, 3, 3);
                dgdtxtcolYear.Visibility = Visibility.Visible;
                dgdtxtcolYear02.Visibility = Visibility.Visible;
                i++;
            }

            if (chkCollectionMonth.IsChecked == true)
            {
                tbkCollection2.Text = i.ToString();
                tbkCollection2.Margin = new Thickness(3, 3, 3, 3);
                dgdtxtcolMonth.Visibility = Visibility.Visible;
                dgdtxtcolMonth02.Visibility = Visibility.Visible;
                i++;
            }

            if (chkCollectionCustom.IsChecked == true)
            {
                tbkCollection3.Text = i.ToString();
                tbkCollection3.Margin = new Thickness(3, 3, 3, 3);
                dgdtxtcolCustom.Visibility = Visibility.Visible;
                dgdtxtcolCustom02.Visibility = Visibility.Visible;
                i++;
            }

            if (chkCollectionAccountTitle.IsChecked == true)
            {
                tbkCollection4.Text = i.ToString();
                tbkCollection4.Margin = new Thickness(3, 3, 3, 3);
                dgdtxtcolAccountTitle.Visibility = Visibility.Visible;
                dgdtxtcolAccountTitle02.Visibility = Visibility.Visible;
                i++;
            }

        }

        #endregion


        // 닫기버튼 클릭.
        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            Lib.Instance.ChildMenuClose(this.ToString());
        }

        // 데이터 그리드 항목 클릭_ SelectionChanged
        private void dgdInGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (tbnOutware.IsChecked == true)
            {
                var WinAccSummary = dgdSummaryGrid.SelectedItem as Win_Acc_RP_Summary_Q_CodeView;
                if (WinAccSummary != null)
                {
                    this.DataContext = WinAccSummary;
                }
            }
        }
        // 데이터 그리드 항목 클릭_ SelectionChanged
        private void dgdOutGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (tbnStuffin.IsChecked == true)
            {
                var WinAccSummary = dgdOutSummaryGrid.SelectedItem as Win_Acc_RP_Summary_Q_CodeView;
                if (WinAccSummary != null)
                {
                    this.DataContext = WinAccSummary;
                }
            }
        }

        // 엑셀 버튼 클릭.
        private void btnExcel_Click(object sender, RoutedEventArgs e)
        {
            DataTable dt = null;
            string Name = string.Empty;

            string[] dgdStr = new string[2];
            if (tbnOutware.IsChecked == true)
            {
                dgdStr[0] = "입금 집계";
                dgdStr[1] = dgdSummaryGrid.Name;
            }
            else
            {
                dgdStr[0] = "출금 집계";
                dgdStr[1] = dgdOutSummaryGrid.Name;
            }

            ExportExcelxaml ExpExc = new ExportExcelxaml(dgdStr);
            ExpExc.ShowDialog();

            if (ExpExc.DialogResult.HasValue)
            {
                if (ExpExc.choice.Equals(dgdSummaryGrid.Name))
                {
                    if (ExpExc.Check.Equals("Y"))
                        dt = Lib.Instance.DataGridToDTinHidden(dgdSummaryGrid);
                    else
                        dt = Lib.Instance.DataGirdToDataTable(dgdSummaryGrid);

                    Name = dgdSummaryGrid.Name;
                    if (Lib.Instance.GenerateExcel(dt, Name))
                        Lib.Instance.excel.Visible = true;
                    else
                        return;
                }
                else if (ExpExc.choice.Equals(dgdOutSummaryGrid.Name))
                {
                    if (ExpExc.Check.Equals("Y"))
                        dt = Lib.Instance.DataGridToDTinHidden(dgdOutSummaryGrid);
                    else
                        dt = Lib.Instance.DataGirdToDataTable(dgdOutSummaryGrid);

                    Name = dgdOutSummaryGrid.Name;
                    if (Lib.Instance.GenerateExcel(dt, Name))
                        Lib.Instance.excel.Visible = true;
                    else
                        return;
                }
                else
                {
                    if (dt != null)
                    {
                        dt.Clear();
                    }
                }
            }
        }


    }


    class Win_Acc_RP_Summary_Q_CodeView
    {
        public override string ToString()
        {
            return (this.ReportAllProperties());
        }

        public int Num { get; set; }
        public bool IsCheck { get; set; }
        public string cls { get; set; }

        public string YYYY { get; set; }
        public string MM { get; set; }
        public string KCustom { get; set; }
        public string Article { get; set; }
        public string BSItem { get; set; }
        public string ForReceiveBillAmount { get; set; }
        public string CurrencyName { get; set; }

        public string RATE { get; set; }

        public string ColorLightLightGray { get; set; }
        public string ColorLightGray { get; set; }
        public string ColorGray { get; set; }

    }    
}
